"""xclim extension module."""
